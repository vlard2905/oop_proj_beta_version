package app.oop_proj;

import java.util.ArrayList;

public class Schedule {
    ArrayList<Entertainments> schedule;

    public void addToSchedule(Entertainments obj) {
        schedule.add(obj);
    }
}
